class Implicant():
    def matches(otherImplicant):
        raise "This class is not intended to be instantiated"