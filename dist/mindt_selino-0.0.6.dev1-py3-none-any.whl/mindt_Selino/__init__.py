from Resources import *
from Implicant import *