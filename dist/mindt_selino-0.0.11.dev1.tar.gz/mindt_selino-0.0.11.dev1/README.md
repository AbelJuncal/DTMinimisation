# DTMinimisation
Repository to store my end-of-degree project
